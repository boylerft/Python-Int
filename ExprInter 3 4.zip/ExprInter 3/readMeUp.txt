Left off at part 6
Adjusting the statements class to use getValueFor for the print statement, in the symTable object.
